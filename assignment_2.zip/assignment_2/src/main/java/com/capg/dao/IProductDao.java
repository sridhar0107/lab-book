package com.capg.dao;

import com.capg.model.Products;

public interface IProductDao{
	public Products addProduct(Products p);
}
